#include <fc/crypto/hex.hpp>
#include <fc/crypto/hmac.hpp>
#include <fc/fwd_impl.hpp>
#include <openssl/sha.h>
#include <string.h>
#include <fc/crypto/sha256.hpp>
#include <fc/variant.hpp>
#include <fc/exception/exception.hpp>
#include "_digest_common.hpp"
#ifdef _SUPPORT_SM_
#include <fc/crypto/sm3.h>
#endif
namespace fc {

    sha256::sha256() { memset( _hash, 0, sizeof(_hash) ); }
    sha256::sha256( const char *data, size_t size ) { 
       if (size != sizeof(_hash))	 
	  FC_THROW_EXCEPTION( exception, "sha256: size mismatch" );
       memcpy(_hash, data, size );
    }
    sha256::sha256( const string& hex_str ) {
      fc::from_hex( hex_str, (char*)_hash, sizeof(_hash) );  
    }

    string sha256::str()const {
      return fc::to_hex( (char*)_hash, sizeof(_hash) );
    }
    sha256::operator string()const { return  str(); }

    char* sha256::data()const { return (char*)&_hash[0]; }


    struct sha256::encoder::impl {
#ifdef _SUPPORT_SM_
		sm3_ctx_t ctx;
#else
		SHA256_CTX ctx;
#endif
    };

    sha256::encoder::~encoder() {}
    sha256::encoder::encoder() {
      reset();
    }

    sha256 sha256::hash( const char* d, uint32_t dlen ) {
      encoder e;
      e.write(d,dlen);
      return e.result();
    }

    sha256 sha256::hash( const string& s ) {
      return hash( s.c_str(), s.size() );
    }

    sha256 sha256::hash( const sha256& s )
    {
        return hash( s.data(), sizeof( s._hash ) );
    }

    void sha256::encoder::write( const char* d, uint32_t dlen ) {
#ifdef _SUPPORT_SM_
		sm3_update( &my->ctx, (const unsigned char*)d, dlen); 
#else
		SHA256_Update(&my->ctx, d, dlen);
#endif
    }
    sha256 sha256::encoder::result() {
      sha256 h;
#ifdef _SUPPORT_SM_
	  sm3_final(&my->ctx,(uint8_t*)h.data());
#else
	  SHA256_Final((uint8_t*)h.data(), &my->ctx);
#endif
      return h;
    }
    void sha256::encoder::reset() {
#ifdef _SUPPORT_SM_
      sm3_init( &my->ctx);
#else
	  SHA256_Init(&my->ctx);
#endif

    }

    sha256 operator << ( const sha256& h1, uint32_t i ) {
      sha256 result;
      fc::detail::shift_l( h1.data(), result.data(), result.data_size(), i );
      return result;
    }
    sha256 operator ^ ( const sha256& h1, const sha256& h2 ) {
      sha256 result;
      result._hash[0] = h1._hash[0] ^ h2._hash[0];
      result._hash[1] = h1._hash[1] ^ h2._hash[1];
      result._hash[2] = h1._hash[2] ^ h2._hash[2];
      result._hash[3] = h1._hash[3] ^ h2._hash[3];
      return result;
    }
    bool operator >= ( const sha256& h1, const sha256& h2 ) {
      return memcmp( h1._hash, h2._hash, sizeof(h1._hash) ) >= 0;
    }
    bool operator > ( const sha256& h1, const sha256& h2 ) {
      return memcmp( h1._hash, h2._hash, sizeof(h1._hash) ) > 0;
    }
    bool operator < ( const sha256& h1, const sha256& h2 ) {
      return memcmp( h1._hash, h2._hash, sizeof(h1._hash) ) < 0;
    }
    bool operator != ( const sha256& h1, const sha256& h2 ) {
      return memcmp( h1._hash, h2._hash, sizeof(h1._hash) ) != 0;
    }
    bool operator == ( const sha256& h1, const sha256& h2 ) {
      return memcmp( h1._hash, h2._hash, sizeof(h1._hash) ) == 0;
    }
  
  void to_variant( const sha256& bi, variant& v )
  {
     v = std::vector<char>( (const char*)&bi, ((const char*)&bi) + sizeof(bi) );
  }
  void from_variant( const variant& v, sha256& bi )
  {
    std::vector<char> ve = v.as< std::vector<char> >();
    if( ve.size() )
    {
        memcpy(&bi, ve.data(), fc::min<size_t>(ve.size(),sizeof(bi)) );
    }
    else
        memset( &bi, char(0), sizeof(bi) );
  }

  uint64_t hash64(const char* buf, size_t len)
  {
    sha256 sha_value = sha256::hash(buf,len);
    return sha_value._hash[0];
  }

    template<>
    unsigned int hmac<sha256>::internal_block_size() const { return 64; }
} //end namespace fc
